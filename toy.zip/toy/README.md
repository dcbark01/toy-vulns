**WARNING** Code here contains explicit toy vulnerabilities for CWEs. Meant for educational use only.

```bash
mkdir build $$ cd build
cmake ..
make

cd ..
./build/tools/type-generator
```